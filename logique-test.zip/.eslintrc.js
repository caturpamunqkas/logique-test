module.exports = {
    extends: [
        'plugin:vue/vue3-recommended'
    ],
    "rules": {
        "no-mixed-spaces-and-tabs": 0, // disable rule
    }
}